package snake

type coord struct {
	x, y int
}
