package main

import "github.com/DyegoCosta/snake-game/snake"

func main() {
	snake.NewGame().Start()
}
